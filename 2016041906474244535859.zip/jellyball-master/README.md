# jellyball
高仿 path下拉小球，类似IOS果冻效果

>详情见博文http://blog.csdn.net/mr_immortalz/article/details/51137319

![这里写图片描述](http://img.blog.csdn.net/20160412234620074)

![这里写图片描述](http://img.blog.csdn.net/20160412234639818)

#四.使用方法#


----------


使用方法也超级简单，三行代码轻松搞定。（因为我把逻辑操作全部封装到了jellyball中，大家可以轻松使用到自己的下拉刷新库中了，只需要获取且暴露出自己下拉刷新库下拉和复位和刷新时的接口即可！）
在Mainacitivty中
![这里写图片描述](http://img.blog.csdn.net/20160412231438109)
